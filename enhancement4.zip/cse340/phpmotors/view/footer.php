<footer>
    <p>&copy; PHP Motors, All rights reserved.</p>
    <p>All images used are believed to be in "Fair Use". Please notify the author if any are not and 
        they will be removed
    </p>
    <p id="lastMod"></p>
</footer>